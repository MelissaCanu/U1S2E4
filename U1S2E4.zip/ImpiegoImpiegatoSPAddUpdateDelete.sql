ALTER PROCEDURE AggiungiAggiornaRimuoviImpiegato (@IDImpiegato INT,
												  @Cognome NVARCHAR(50),
												  @Nome NVARCHAR(50),
												  @CodiceFiscale NVARCHAR(16),
												  @Eta INT,
												  @RedditoMensile DECIMAL(10,2),
												  @DetrazioneFiscale BIT,
												  @StatementType NVARCHAR(20) = '')

AS 
  BEGIN
       IF @StatementType = 'Insert'
	     BEGIN
		      INSERT INTO IMPIEGATO
			              (IDImpiegato,
						  Cognome,
						  Nome,
						  CodiceFiscale,
						  Eta,
						  RedditoMensile,
						  DetrazioneFiscale)
			  VALUES      (@IDImpiegato,
			              @Cognome,
						  @Nome,
						  @CodiceFiscale,
						  @Eta,
						  @RedditoMensile,
						  @DetrazioneFiscale)
		  END

		IF @StatementType = 'Update'
		  BEGIN
		       UPDATE IMPIEGATO
			   SET    
			          Cognome = @Cognome,
				      Nome = @Nome,
					  CodiceFiscale = @CodiceFiscale,
					  Eta = @Eta,
					  RedditoMensile = @RedditoMensile,
					  DetrazioneFiscale = @DetrazioneFiscale
			   WHERE  IDImpiegato = @IDImpiegato
		   END
		ELSE IF @StatementType = 'Delete'
		   BEGIN
		       DELETE FROM IMPIEGATO
			   WHERE IDImpiegato = @IDImpiegato
		   END
  END
						   